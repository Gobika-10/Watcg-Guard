import { Outlet } from "react-router-dom";
import { SideNav } from "./components/SideNav";
import { TopBar } from "./components/TopBar";

export const AppLayout = () => {
  return (
    <div className="flex min-h-screen bg-slate-100 text-slate-900">
      <SideNav />
      <div className="flex min-h-screen flex-1 flex-col">
        <TopBar />
        <main className="flex-1 p-4 md:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};
