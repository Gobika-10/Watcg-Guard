import type { ComponentType } from "react";
import {
  BarChart3,
  FileText,
  Headset,
  Home,
  Package2,
  RefreshCw,
  Settings,
  Receipt,
} from "lucide-react";
import { NavLink } from "react-router-dom";
import { useAppSelector } from "../../app/hooks";
import type { UiIconKey } from "../../features/ui/uiSlice";

const iconMap: Record<UiIconKey, ComponentType<{ className?: string }>> = {
  dashboard: Home,
  newPurchase: Package2,
  renewals: RefreshCw,
  invoicesBilling: FileText,
  usageReports: BarChart3,
  supportTickets: Headset,
  accountSettings: Settings,
  billing: Receipt,
};

export const SideNav = () => {
  const { brand, navigationItems } = useAppSelector((state) => state.ui);

  return (
    <aside className="hidden lg:block w-[283px] shrink-0 bg-[#142B57] text-white border-r border-white/10 min-h-screen">
      <div className="flex h-full flex-col">
        {/* Brand */}
        <div className="border-b border-white/10 px-6 py-6">
          <div className="flex items-center">
            <h1 className="text-[22px] font-semibold tracking-tight text-white">
              {brand.name}
            </h1>
          </div>
          {brand.subtitle && (
            <p className="mt-1 text-xs text-white/60">{brand.subtitle}</p>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-5">
          <div className="space-y-2">
            {navigationItems.map((item) => {
              const Icon = iconMap[item.iconKey];

              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) =>
                    [
                      "group relative flex items-center gap-4 rounded-[14px] px-5 py-4 text-[15px] font-medium transition-all duration-200",
                      isActive
                        ? "bg-[#2B2448] text-red-500 border border-white/80 shadow-[0_0_0_1px_rgba(255,255,255,0.08)]"
                        : "text-white/90 hover:bg-white/5 hover:text-white",
                    ].join(" ")
                  }
                >
                  {({ isActive }) => (
                    <>
                      {isActive && (
                        <span className="absolute left-0 top-1/2 h-[84%] w-[3px] -translate-y-1/2 rounded-r-full bg-red-600" />
                      )}

                      <Icon
                        className={`h-5 w-5 shrink-0 ${
                          isActive
                            ? "text-red-500"
                            : "text-white/80 group-hover:text-white"
                        }`}
                      />

                      <span
                        className={`leading-none ${
                          isActive ? "text-red-500" : "text-white/90"
                        }`}
                      >
                        {item.label}
                      </span>
                    </>
                  )}
                </NavLink>
              );
            })}
          </div>
        </nav>
        <div className="px-4 pb-5">
    <div className="rounded-xl bg-white/5 p-4 border border-white/10">
      
      {/* Top Row */}
      <div className="flex items-center gap-3 mb-3">
        <div className="flex items-center justify-center w-9 h-9 rounded-full bg-yellow-400 text-white">
          ⭐
        </div>
        <span className="text-white font-semibold">Gold Partner</span>
      </div>

      {/* Details */}
      <div className="text-sm text-white/80 space-y-1">
        <p className="font-medium text-white/90">Account Manager</p>
        <p>Sarah Mitchell</p>
        <button className="text-blue-400 hover:underline text-sm">
          Contact
        </button>
      </div>

    </div>
  </div>
      </div>
    </aside>
  );
};