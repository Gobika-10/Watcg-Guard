import { Bell, Settings, UserCircle2 } from "lucide-react";
import { useLocation } from "react-router-dom";
import { useAppSelector } from "../../app/hooks";

export const TopBar = () => {
  const location = useLocation();
  const { topBarMeta, navigationItems } = useAppSelector((state) => state.ui);
  const activeNav = navigationItems.find((item) => item.path === location.pathname);
  const pageName = activeNav?.label ?? "Dashboard";

  return (
    <header className="border-b border-slate-200 bg-white px-5 py-4 md:px-7">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">{pageName}</h2>
          <p className="mt-1 text-sm text-slate-500">
            {topBarMeta.breadcrumbRoot} / {pageName}
          </p>
        </div>

        <div className="flex items-start gap-5">
          <div className="mt-1 hidden items-center gap-4 text-slate-500 md:flex">
            <button type="button" className="transition-colors hover:text-slate-900">
              <Bell className="h-5 w-5" />
            </button>
            <button type="button" className="transition-colors hover:text-slate-900">
              <Settings className="h-5 w-5" />
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-sm font-semibold text-slate-900">{topBarMeta.company}</p>
              <p className="text-xs text-amber-600">{topBarMeta.tier}</p>
            </div>
            <UserCircle2 className="h-10 w-10 text-slate-700" />
          </div>
        </div>
      </div>
    </header>
  );
};
