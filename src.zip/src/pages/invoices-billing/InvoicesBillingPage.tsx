import { useMemo } from "react";
import { useAppDispatch, useAppSelector } from "../../app/hooks";
import { AutoRenewCard } from "../../components/invoices-billing/AutoRenewCard";
import { BillingAddressCard } from "../../components/invoices-billing/BillingAddressCard";
import { BillingSummaryCard } from "../../components/invoices-billing/BillingSummaryCard";
import { InvoicesTableCard } from "../../components/invoices-billing/InvoicesTableCard";
import { PaymentMethodsCard } from "../../components/invoices-billing/PaymentMethodsCard";
import {
  setCustomerFilter,
  setPeriodFilter,
  setStatusFilter,
  toggleAutoRenew,
} from "../../features/invoicesBilling/invoicesBillingSlice";

export const InvoicesBillingPage = () => {
  const dispatch = useAppDispatch();
  const billing = useAppSelector((state) => state.invoicesBilling);

  const filteredInvoices = useMemo(() => {
    return billing.invoices.filter((invoice) => {
      const customerMatch =
        billing.filters.customer === "All Customers" ||
        invoice.customer === billing.filters.customer;

      const statusMatch =
        billing.filters.status === "All Status" || invoice.status === billing.filters.status;

      return customerMatch && statusMatch;
    });
  }, [billing.invoices, billing.filters.customer, billing.filters.status]);

  return (
    <div className="grid grid-cols-1 gap-3 lg:grid-cols-[2fr_1fr]">
      <InvoicesTableCard
        invoices={filteredInvoices}
        filterOptions={billing.filterOptions}
        filters={billing.filters}
        onCustomerChange={(value) => dispatch(setCustomerFilter(value))}
        onPeriodChange={(value) => dispatch(setPeriodFilter(value))}
        onStatusChange={(value) => dispatch(setStatusFilter(value))}
      />

      <div className="space-y-3">
        <BillingSummaryCard
          currentBalance={billing.billingSummary.currentBalance}
          lastPaymentAmount={billing.billingSummary.lastPaymentAmount}
          lastPaymentDate={billing.billingSummary.lastPaymentDate}
          nextInvoiceDue={billing.billingSummary.nextInvoiceDue}
        />

        <PaymentMethodsCard methods={billing.paymentMethods} />

        <BillingAddressCard
          company={billing.billingAddress.company}
          lines={billing.billingAddress.lines}
        />

        <AutoRenewCard
          enabled={billing.autoRenewEnabled}
          onToggle={() => dispatch(toggleAutoRenew())}
        />
      </div>
    </div>
  );
};
