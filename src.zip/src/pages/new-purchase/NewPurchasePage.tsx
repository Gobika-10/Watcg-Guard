import { CircleHelp } from "lucide-react";
import { useAppDispatch, useAppSelector } from "../../app/hooks";
import { CategoryTabs } from "../../components/new-purchase/CategoryTabs";
import { CustomerSelect } from "../../components/new-purchase/CustomerSelect";
import { ProductGrid } from "../../components/new-purchase/ProductGrid";
import { PurchaseStepper } from "../../components/new-purchase/PurchaseStepper";
import {
  goToConfigureStep,
  nextStep,
  prevStep,
  resetPurchaseFlow,
  setSelectedCategory,
  setSelectedCustomer,
} from "../../features/newPurchase/newPurchaseSlice";

export const NewPurchasePage = () => {
  const dispatch = useAppDispatch();
  const newPurchase = useAppSelector((state) => state.newPurchase);

  const selectedProduct = newPurchase.products.find(
    (product) => product.id === newPurchase.selectedProductId
  );

  return (
    <div className="relative space-y-3 p-4">
      <PurchaseStepper
        activeStep={newPurchase.activeStep}
        steps={newPurchase.steps}
      />

      {newPurchase.activeStep === 1 && (
        <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
          <h3 className="text-base font-semibold text-slate-900">
            Browse Products
          </h3>

          <div className="mt-4">
            <CustomerSelect
              customers={newPurchase.customers}
              value={newPurchase.selectedCustomerId}
              onChange={(customerId) => dispatch(setSelectedCustomer(customerId))}
            />
          </div>

          <CategoryTabs
            categories={newPurchase.categories}
            selectedKey={newPurchase.selectedCategory}
            onSelect={(category) => dispatch(setSelectedCategory(category))}
          />

          <ProductGrid
            products={newPurchase.products}
            selectedCategory={newPurchase.selectedCategory}
            onConfigure={(productId) => dispatch(goToConfigureStep(productId))}
          />
        </section>
      )}

      {newPurchase.activeStep === 2 && (
        <section className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <button
            type="button"
            onClick={() => dispatch(prevStep())}
            className="mb-5 text-sm font-medium text-blue-600 hover:text-blue-700"
          >
            ← Back to Products
          </button>

          <h3 className="text-3xl font-semibold text-slate-900">
            {selectedProduct?.name || "Configure Product"}
          </h3>

          <div className="mt-8 grid gap-4 md:grid-cols-3">
            <button className="rounded-xl border-2 border-red-500 bg-red-50 px-6 py-5 text-center">
              <div className="text-xl font-semibold text-slate-900">1 Year</div>
            </button>

            <button className="rounded-xl border border-slate-300 bg-white px-6 py-5 text-center">
              <div className="text-xl font-semibold text-slate-900">2 Years</div>
              <div className="mt-1 text-sm text-slate-500">Save 5%</div>
            </button>

            <button className="rounded-xl border border-slate-300 bg-white px-6 py-5 text-center">
              <div className="text-xl font-semibold text-slate-900">3 Years</div>
              <div className="mt-1 text-sm text-slate-500">Save 10%</div>
            </button>
          </div>

          <div className="mt-8">
            <label className="mb-2 block text-sm font-medium text-slate-700">
              Number of Licenses/Seats
            </label>
            <div className="flex items-center gap-3">
              <button className="h-12 w-12 rounded-lg bg-slate-100 text-xl font-semibold">
                -
              </button>
              <div className="flex h-12 flex-1 items-center justify-center rounded-lg border border-slate-300 bg-white text-xl font-semibold">
                1
              </div>
              <button className="h-12 w-12 rounded-lg bg-slate-100 text-xl font-semibold">
                +
              </button>
            </div>
          </div>

          <div className="mt-8">
            <label className="mb-2 block text-sm font-medium text-slate-700">
              Billing Cycle
            </label>
            <select className="w-full rounded-lg border border-slate-300 bg-white px-4 py-3 outline-none">
              <option>Annual Upfront</option>
            </select>
          </div>

          <div className="mt-8">
            <label className="mb-3 block text-sm font-medium text-slate-700">
              Add-ons (Optional)
            </label>

            <div className="space-y-3">
              <label className="flex items-center gap-3 rounded-lg border border-slate-200 px-4 py-3">
                <input type="checkbox" />
                <span>Priority Support</span>
              </label>

              <label className="flex items-center gap-3 rounded-lg border border-slate-200 px-4 py-3">
                <input type="checkbox" />
                <span>Advanced Analytics</span>
              </label>

              <label className="flex items-center gap-3 rounded-lg border border-slate-200 px-4 py-3">
                <input type="checkbox" />
                <span>Custom Training</span>
              </label>
            </div>
          </div>

          <div className="mt-8 flex justify-end">
            <div className="w-full max-w-sm rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
              <h4 className="text-2xl font-semibold text-slate-900">
                Price Summary
              </h4>

              <div className="mt-5 space-y-3 text-sm text-slate-600">
                <div className="flex justify-between">
                  <span>Unit Price</span>
                  <span className="font-semibold text-slate-900">$2499</span>
                </div>
                <div className="flex justify-between">
                  <span>Quantity</span>
                  <span className="font-semibold text-slate-900">1 license</span>
                </div>
                <div className="flex justify-between">
                  <span>Term</span>
                  <span className="font-semibold text-slate-900">1 Year</span>
                </div>
              </div>

              <div className="my-6 border-t border-slate-200" />

              <div className="flex items-center justify-between">
                <span className="text-2xl font-semibold text-slate-900">
                  Total
                </span>
                <span className="text-4xl font-bold text-red-600">$2,499</span>
              </div>

              <button
                type="button"
                onClick={() => dispatch(nextStep())}
                className="mt-6 w-full rounded-lg bg-orange-500 px-4 py-3 text-base font-semibold text-white hover:bg-orange-600"
              >
                Add to Cart
              </button>
            </div>
          </div>
        </section>
      )}

      {newPurchase.activeStep === 3 && (
        <section className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <h3 className="text-3xl font-semibold text-slate-900">Review Cart</h3>

          <div className="mt-8 rounded-lg border border-slate-200 p-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-2xl font-semibold text-slate-900">
                  {selectedProduct?.name || "Firebox M290"}
                </h4>
                <p className="mt-1 text-sm text-slate-500">
                  1 Year | 1 licenses | Annual Upfront
                </p>
              </div>
              <div className="text-3xl font-bold text-slate-900">$2,499</div>
            </div>
          </div>

          <div className="my-6 border-t border-slate-200" />

          <div className="flex gap-3">
            <input
              type="text"
              placeholder="Enter promo code"
              className="flex-1 rounded-lg border border-slate-300 px-4 py-3 outline-none"
            />
            <button className="rounded-lg bg-slate-200 px-6 py-3 font-semibold text-slate-900">
              Apply
            </button>
          </div>

          <div className="mt-6 space-y-2 text-sm text-slate-600">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span className="font-semibold text-slate-900">$2,499</span>
            </div>
            <div className="flex justify-between">
              <span>Tax (estimated)</span>
              <span>$199.92</span>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between border-t border-slate-200 pt-4">
            <span className="text-3xl font-semibold text-slate-900">
              Total Due
            </span>
            <span className="text-4xl font-bold text-slate-900">$2,698.92</span>
          </div>

          <div className="mt-8 flex gap-4">
            <button
              type="button"
              onClick={() => dispatch(prevStep())}
              className="rounded-lg border border-slate-300 bg-white px-6 py-3 font-semibold text-slate-900"
            >
              ← Continue Shopping
            </button>

            <button
              type="button"
              onClick={() => dispatch(nextStep())}
              className="flex-1 rounded-lg bg-orange-500 px-6 py-3 font-semibold text-white hover:bg-orange-600"
            >
              Proceed to Review →
            </button>
          </div>
        </section>
      )}

      {newPurchase.activeStep === 4 && (
        <section className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
          <h3 className="text-3xl font-semibold text-slate-900">
            Review Order Summary
          </h3>

          <div className="mt-8 grid gap-4 md:grid-cols-2">
            <div className="rounded-lg border border-slate-200 p-4">
              <h4 className="text-2xl font-semibold text-slate-900">
                Billing Details
              </h4>
              <div className="mt-4 space-y-2 text-slate-600">
                <p>Acme IT Solutions</p>
                <p>john.smith@acmeit.com</p>
                <p>Payment: Credit Card ****4242</p>
              </div>
            </div>

            <div className="rounded-lg border border-slate-200 p-4">
              <h4 className="text-2xl font-semibold text-slate-900">
                Order Summary
              </h4>
              <div className="mt-4 space-y-2 text-slate-600">
                <p>1 product(s)</p>
                <p>Total: $2,698.92</p>
                <p className="text-green-600">Estimated delivery: Immediate</p>
              </div>
            </div>
          </div>

          <div className="mt-6 space-y-3">
            <label className="flex items-center gap-3 rounded-lg border border-slate-200 px-4 py-3">
              <input type="checkbox" />
              <span>I agree to the Terms & Conditions</span>
            </label>

            <label className="flex items-center gap-3 rounded-lg border border-slate-200 px-4 py-3">
              <input type="checkbox" defaultChecked />
              <span>Enable Auto-Renew for these subscriptions</span>
            </label>
          </div>

          <div className="mt-8 flex gap-4">
            <button
              type="button"
              onClick={() => dispatch(prevStep())}
              className="rounded-lg border border-slate-300 bg-white px-6 py-3 font-semibold text-slate-900"
            >
              ← Back
            </button>

            <button
              type="button"
              onClick={() => dispatch(nextStep())}
              className="flex-1 rounded-lg bg-orange-500 px-6 py-3 font-semibold text-white hover:bg-orange-600"
            >
              Place Order →
            </button>
          </div>
        </section>
      )}

      {newPurchase.activeStep === 5 && (
        <section className="rounded-xl border border-slate-200 bg-white p-10 text-center shadow-sm">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-green-500 text-4xl text-white">
            ✓
          </div>

          <h3 className="mt-6 text-4xl font-bold text-slate-900">
            Order Placed Successfully!
          </h3>

          <p className="mt-3 text-lg text-slate-600">
            Order Number: <span className="font-semibold">WG-72146345</span>
          </p>

          <p className="mt-2 text-slate-500">
            A confirmation email has been sent to your registered email address.
          </p>

          <h4 className="mt-10 text-2xl font-semibold text-slate-900">
            What's Next?
          </h4>

          <div className="mx-auto mt-6 grid max-w-4xl gap-4 md:grid-cols-3">
            <div className="rounded-lg bg-slate-50 p-5">
              <div className="text-3xl">✅</div>
              <h5 className="mt-3 font-semibold text-slate-900">
                Account Provisioned
              </h5>
              <p className="mt-2 text-sm text-slate-500">
                Your services are being set up
              </p>
            </div>

            <div className="rounded-lg bg-slate-50 p-5">
              <div className="text-3xl">📚</div>
              <h5 className="mt-3 font-semibold text-slate-900">
                Onboarding Resources
              </h5>
              <p className="mt-2 text-sm text-slate-500">
                Check your email for guides
              </p>
            </div>

            <div className="rounded-lg bg-slate-50 p-5">
              <div className="text-3xl">🔔</div>
              <h5 className="mt-3 font-semibold text-slate-900">
                Renewal Reminders
              </h5>
              <p className="mt-2 text-sm text-slate-500">
                We'll notify you in advance
              </p>
            </div>
          </div>

          <div className="mt-8 flex items-center justify-center gap-4">
            <button
              type="button"
              className="rounded-lg border-2 border-blue-600 bg-white px-6 py-3 font-semibold text-blue-600"
            >
              Download Invoice
            </button>

            <button
              type="button"
              onClick={() => dispatch(resetPurchaseFlow())}
              className="rounded-lg bg-red-600 px-6 py-3 font-semibold text-white hover:bg-red-700"
            >
              Go to Dashboard
            </button>
          </div>
        </section>
      )}

      <button
        type="button"
        className="fixed bottom-5 right-5 flex h-12 w-12 items-center justify-center rounded-full bg-red-600 text-white shadow-md transition hover:bg-red-700"
        aria-label="Help"
      >
        <CircleHelp className="h-5 w-5" />
      </button>
    </div>
  );
};
