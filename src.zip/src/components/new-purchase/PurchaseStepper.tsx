import type { StepItem } from "../../features/newPurchase/newPurchaseSlice";

interface PurchaseStepperProps {
  activeStep: number;
  steps: StepItem[];
}

export const PurchaseStepper = ({
  activeStep,
  steps,
}: PurchaseStepperProps) => {
  return (
    <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-center gap-4 overflow-x-auto">
        {steps.map((step, i) => {
          const num = i + 1;
          const isActive = num === activeStep;
          const isDone = num < activeStep;

          return (
            <div key={step.key} className="flex min-w-fit flex-1 items-center">
              <div className="flex items-center gap-3">
                <div
                  className={[
                    "flex h-10 w-10 items-center justify-center rounded-full text-sm font-semibold",
                    isDone
                      ? "bg-green-500 text-white"
                      : isActive
                      ? "bg-red-600 text-white"
                      : "bg-slate-200 text-slate-700",
                  ].join(" ")}
                >
                  {isDone ? "✓" : num}
                </div>

                <div className="whitespace-nowrap">
                  <p className="text-sm font-semibold text-slate-900">
                    {step.title}
                  </p>
                  <p
                    className={[
                      "text-sm",
                      isActive || isDone ? "text-slate-700" : "text-slate-400",
                    ].join(" ")}
                  >
                    {step.subtitle}
                  </p>
                </div>
              </div>

              {i < steps.length - 1 && (
                <div
                  className={[
                    "mx-4 h-1 flex-1 rounded",
                    isDone ? "bg-green-500" : "bg-slate-200",
                  ].join(" ")}
                />
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};