import { Flame, Globe2, Lock } from "lucide-react";
import type { ComponentType } from "react";
import type { ProductIconKey } from "../../features/newPurchase/newPurchaseSlice";

interface ProductCardProps {
  name: string;
  description: string;
  priceLabel: string;
  iconKey: ProductIconKey;
  onConfigure?: () => void;
}

const iconMap: Record<ProductIconKey, ComponentType<{ className?: string }>> = {
  flame: Flame,
  lock: Lock,
  globe: Globe2,
};

const toneMap: Record<ProductIconKey, string> = {
  flame: "text-orange-500",
  lock: "text-amber-500",
  globe: "text-sky-500",
};

export const ProductCard = ({
  name,
  description,
  priceLabel,
  iconKey,
  onConfigure,
}: ProductCardProps) => {
  const Icon = iconMap[iconKey];

  return (
    <article className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
      <Icon className={`h-7 w-7 ${toneMap[iconKey]}`} />
      <h3 className="mt-3 text-3xl font-bold text-slate-900">{name}</h3>
      <p className="mt-2 min-h-[56px] text-base leading-relaxed text-slate-600">{description}</p>
      <p className="mt-4 text-slate-600">
        <span className="text-base">Starting from </span>
        <span className="text-3xl font-bold text-slate-900">{priceLabel}</span>
        <span className="text-base">/user/yr</span>
      </p>
      <button
        type="button"
        onClick={onConfigure}
        className="mt-4 w-full rounded-lg bg-sky-600 px-4 py-2.5 text-lg font-semibold text-white transition hover:bg-sky-700"
      >
        Configure →
      </button>
    </article>
  );
};
