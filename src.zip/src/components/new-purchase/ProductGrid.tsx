import {
  Cloud,
  Flame,
  Lock,
  Shield,
  User,
  Globe,
} from "lucide-react";
import type {
  ProductItem,
  PurchaseCategoryKey,
} from "../../features/newPurchase/newPurchaseSlice";

interface ProductGridProps {
  products: ProductItem[];
  selectedCategory: PurchaseCategoryKey;
  onConfigure: (productId: string) => void;
}

const iconMap = {
  flame: Flame,
  lock: Lock,
  globe: Globe,
  shield: Shield,
  user: User,
  cloud: Cloud,
};

export const ProductGrid = ({
  products,
  selectedCategory,
  onConfigure,
}: ProductGridProps) => {
  const filteredProducts = products.filter(
    (product) => product.category === selectedCategory
  );

  return (
    <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      {filteredProducts.map((product) => {
        const Icon = iconMap[product.iconKey];

        return (
          <div
            key={product.id}
            className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm transition hover:shadow-md"
          >
            <div
              className="flex h-12 w-12 items-center justify-center rounded-xl"
              style={{ backgroundColor: product.iconBg }}
            >
              <Icon
                className="h-6 w-6"
                style={{ color: product.iconColor }}
              />
            </div>

            <h4 className="mt-4 text-lg font-semibold text-slate-900">
              {product.name}
            </h4>

            <p className="mt-2 text-sm leading-6 text-slate-500">
              {product.description}
            </p>

            <div className="mt-5 flex items-center justify-between">
              <span className="text-lg font-bold text-slate-900">
                {product.priceLabel}
              </span>

              <button
                type="button"
                onClick={() => onConfigure(product.id)}
                className="rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-red-700"
              >
                Configure
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
};