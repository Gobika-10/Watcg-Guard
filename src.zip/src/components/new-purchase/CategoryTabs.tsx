import type { ComponentType } from "react";
import { Cloud, Lock, Shield, UserRound } from "lucide-react";
import type {
  PurchaseCategoryIconKey,
  PurchaseCategoryKey,
} from "../../features/newPurchase/newPurchaseSlice";

interface CategoryItem {
  key: PurchaseCategoryKey;
  label: string;
  iconKey: PurchaseCategoryIconKey;
}

interface CategoryTabsProps {
  categories: CategoryItem[];
  selectedKey: PurchaseCategoryKey;
  onSelect: (key: PurchaseCategoryKey) => void;
}

const iconMap: Record<PurchaseCategoryIconKey, ComponentType<{ className?: string }>> = {
  lock: Lock,
  shield: Shield,
  user: UserRound,
  cloud: Cloud,
};

const iconToneMap: Record<PurchaseCategoryKey, string> = {
  networkSecurity: "text-blue-600",
  endpoint: "text-violet-600",
  identity: "text-emerald-600",
  cloud: "text-sky-600",
};

export const CategoryTabs = ({ categories, selectedKey, onSelect }: CategoryTabsProps) => {
  return (
    <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
      {categories.map((category) => {
        const Icon = iconMap[category.iconKey];
        const isSelected = selectedKey === category.key;

        return (
          <button
            key={category.key}
            type="button"
            onClick={() => onSelect(category.key)}
            className={[
              "rounded-lg border bg-white p-4 text-center transition-all",
              isSelected
                ? "border-red-500 ring-2 ring-red-100"
                : "border-slate-200 hover:border-slate-300 hover:shadow-sm",
            ].join(" ")}
          >
            <Icon className={`mx-auto h-6 w-6 ${iconToneMap[category.key]}`} />
            <p className="mt-2 text-xl font-semibold text-slate-800">{category.label}</p>
          </button>
        );
      })}
    </div>
  );
};
