interface BillingSummaryCardProps {
  currentBalance: string;
  lastPaymentAmount: string;
  lastPaymentDate: string;
  nextInvoiceDue: string;
}

export const BillingSummaryCard = ({
  currentBalance,
  lastPaymentAmount,
  lastPaymentDate,
  nextInvoiceDue,
}: BillingSummaryCardProps) => {
  return (
    <section className="rounded-lg border border-slate-200 bg-white p-3.5 shadow-sm">
      <h3 className="text-base font-semibold text-slate-900">Billing Summary</h3>

      <div className="mt-2 border-b border-slate-200 pb-2.5">
        <p className="text-[11px] text-slate-500">Current Balance</p>
        <p className="text-3xl font-bold text-rose-600">{currentBalance}</p>
      </div>

      <div className="border-b border-slate-200 py-2.5">
        <p className="text-[11px] text-slate-500">Last Payment</p>
        <p className="text-sm font-semibold text-slate-800">{lastPaymentAmount}</p>
        <p className="text-xs text-slate-500">{lastPaymentDate}</p>
      </div>

      <div className="py-2.5">
        <p className="text-[11px] text-slate-500">Next Invoice Due</p>
        <p className="text-sm font-semibold text-slate-800">{nextInvoiceDue}</p>
      </div>

      <button
        type="button"
        className="mt-2.5 h-10 w-full rounded-md bg-red-600 text-sm font-semibold text-white transition hover:bg-red-700"
      >
        Pay Outstanding Balance
      </button>
    </section>
  );
};
