interface AutoRenewCardProps {
  enabled: boolean;
  onToggle: () => void;
}

export const AutoRenewCard = ({ enabled, onToggle }: AutoRenewCardProps) => {
  return (
    <section className="rounded-lg border border-slate-200 bg-white p-3.5 shadow-sm">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="text-base font-semibold text-slate-900">Auto-Renew Settings</h3>
          <p className="mt-1 text-xs text-slate-600">Enable auto-renew for all subscriptions</p>
          <p className="mt-1 text-[10px] text-slate-500">
            When enabled, your subscriptions will automatically renew before expiration using your
            default payment method.
          </p>
        </div>

        <button
          type="button"
          role="switch"
          aria-checked={enabled}
          onClick={onToggle}
          className={[
            "relative mt-0.5 h-5 w-9 rounded-full transition",
            enabled ? "bg-emerald-500" : "bg-slate-300",
          ].join(" ")}
        >
          <span
            className={[
              "absolute left-0.5 top-0.5 h-4 w-4 rounded-full bg-white transition-transform",
              enabled ? "translate-x-4" : "translate-x-0",
            ].join(" ")}
          />
        </button>
      </div>
    </section>
  );
};
