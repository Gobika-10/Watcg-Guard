import { InvoiceFilters } from "./InvoiceFilters";

interface InvoiceItem {
  id: string;
  customer: string;
  date: string;
  description: string;
  amount: string;
  status: "Paid" | "Outstanding";
}

interface InvoicesTableCardProps {
  invoices: InvoiceItem[];
  filterOptions: {
    customers: string[];
    periods: string[];
    statuses: string[];
  };
  filters: {
    customer: string;
    period: string;
    status: string;
  };
  onCustomerChange: (value: string) => void;
  onPeriodChange: (value: string) => void;
  onStatusChange: (value: string) => void;
}

export const InvoicesTableCard = ({
  invoices,
  filterOptions,
  filters,
  onCustomerChange,
  onPeriodChange,
  onStatusChange,
}: InvoicesTableCardProps) => {
  return (
    <section className="rounded-lg border border-slate-200 bg-white p-3.5 shadow-sm">
      <h3 className="mb-2 text-xl font-semibold text-slate-900">Invoices</h3>

      <InvoiceFilters
        customers={filterOptions.customers}
        periods={filterOptions.periods}
        statuses={filterOptions.statuses}
        selectedCustomer={filters.customer}
        selectedPeriod={filters.period}
        selectedStatus={filters.status}
        onCustomerChange={onCustomerChange}
        onPeriodChange={onPeriodChange}
        onStatusChange={onStatusChange}
      />

      <div className="overflow-x-auto">
        <table className="w-full min-w-[760px]">
          <thead>
            <tr className="border-b border-slate-200 text-left">
              {["Customer", "Invoice #", "Date", "Description", "Amount", "Status", "Actions"].map(
                (head) => (
                  <th
                    key={head}
                    className="py-2 pr-3 text-[10px] font-semibold uppercase tracking-wide text-slate-500"
                  >
                    {head}
                  </th>
                )
              )}
            </tr>
          </thead>
          <tbody>
            {invoices.map((invoice) => (
              <tr key={invoice.id} className="border-b border-slate-100">
                <td className="py-2.5 pr-3 text-xs text-slate-700">{invoice.customer}</td>
                <td className="py-2.5 pr-3 text-xs font-semibold text-slate-800">{invoice.id}</td>
                <td className="py-2.5 pr-3 text-xs text-slate-700">{invoice.date}</td>
                <td className="py-2.5 pr-3 text-xs text-slate-700">{invoice.description}</td>
                <td className="py-2.5 pr-3 text-xs font-semibold text-slate-800">{invoice.amount}</td>
                <td className="py-2.5 pr-3">
                  <span
                    className={[
                      "rounded-full px-2 py-0.5 text-[10px] font-semibold",
                      invoice.status === "Paid"
                        ? "bg-emerald-100 text-emerald-700"
                        : "bg-amber-100 text-amber-700",
                    ].join(" ")}
                  >
                    {invoice.status}
                  </span>
                </td>
                <td className="py-2.5 text-xs">
                  <button type="button" className="font-semibold text-sky-700 hover:text-sky-800">
                    View
                  </button>
                  <span className="px-1 text-slate-400">•</span>
                  <button type="button" className="font-semibold text-sky-700 hover:text-sky-800">
                    PDF
                  </button>
                  {invoice.status === "Outstanding" ? (
                    <>
                      <span className="px-1 text-slate-400">•</span>
                      <button type="button" className="font-semibold text-rose-600 hover:text-rose-700">
                        Pay Now
                      </button>
                    </>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
};
