interface BillingAddressCardProps {
  company: string;
  lines: string[];
}

export const BillingAddressCard = ({ company, lines }: BillingAddressCardProps) => {
  return (
    <section className="rounded-lg border border-slate-200 bg-white p-3.5 shadow-sm">
      <h3 className="text-base font-semibold text-slate-900">Billing Address</h3>
      <div className="mt-2 space-y-0.5 text-xs text-slate-600">
        <p className="font-semibold text-slate-800">{company}</p>
        {lines.map((line) => (
          <p key={line}>{line}</p>
        ))}
      </div>
      <button type="button" className="mt-2 text-xs font-semibold text-sky-700 hover:text-sky-800">
        Edit Address
      </button>
    </section>
  );
};
