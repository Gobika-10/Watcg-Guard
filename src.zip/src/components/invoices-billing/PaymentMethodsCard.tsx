import { CreditCard } from "lucide-react";

interface PaymentMethod {
  id: string;
  label: string;
  expiry: string;
  isDefault: boolean;
}

interface PaymentMethodsCardProps {
  methods: PaymentMethod[];
}

export const PaymentMethodsCard = ({ methods }: PaymentMethodsCardProps) => {
  return (
    <section className="rounded-lg border border-slate-200 bg-white p-3.5 shadow-sm">
      <div className="flex items-center justify-between">
        <h3 className="text-base font-semibold text-slate-900">Payment Methods</h3>
        <button type="button" className="text-xs font-semibold text-sky-700 hover:text-sky-800">
          + Add New
        </button>
      </div>

      <div className="mt-2 space-y-2">
        {methods.map((method) => (
          <article
            key={method.id}
            className="flex items-center justify-between rounded-md border border-sky-200 bg-sky-50 px-3 py-2"
          >
            <div className="flex items-center gap-2">
              <CreditCard className="h-4 w-4 text-slate-600" />
              <div>
                <p className="text-sm font-semibold text-slate-800">{method.label}</p>
                <p className="text-[11px] text-slate-500">{method.expiry}</p>
              </div>
            </div>
            {method.isDefault ? (
              <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-semibold text-emerald-700">
                Default
              </span>
            ) : null}
          </article>
        ))}
      </div>
    </section>
  );
};
