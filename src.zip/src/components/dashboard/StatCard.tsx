import { BadgeDollarSign, Boxes, CalendarClock, KeyRound, UsersRound } from "lucide-react";

type StatTone = "emerald" | "blue" | "rose" | "orange";

const toneStyles: Record<StatTone, { text: string; bg: string; ring: string }> = {
  emerald: { text: "text-emerald-600", bg: "bg-emerald-100", ring: "ring-emerald-200" },
  blue: { text: "text-sky-600", bg: "bg-sky-100", ring: "ring-sky-200" },
  rose: { text: "text-rose-600", bg: "bg-rose-100", ring: "ring-rose-200" },
  orange: { text: "text-orange-600", bg: "bg-orange-100", ring: "ring-orange-200" },
};

const icons = [UsersRound, Boxes, KeyRound, BadgeDollarSign, CalendarClock];

interface StatCardProps {
  index: number;
  title: string;
  value: string;
  subtitle: string;
  note?: string;
  tone: StatTone;
}

export const StatCard = ({ index, title, value, subtitle, note, tone }: StatCardProps) => {
  const Icon = icons[index] ?? UsersRound;
  const s = toneStyles[tone];

  return (
    <article className="group relative overflow-hidden rounded-xl border border-slate-200 bg-white p-4 shadow-sm transition-all hover:-translate-y-0.5 hover:border-slate-300">
      <div className="flex items-start justify-between">
        <div className={`inline-flex items-center justify-center rounded-lg p-2 ring-1 ${s.bg} ${s.ring}`}>
          <Icon className={`h-4 w-4 ${s.text}`} />
        </div>
        <div className={`pointer-events-none h-16 w-16 rounded-full ${s.bg} blur-2xl opacity-50`} />
      </div>

      <p className="mt-3 text-2xl font-bold leading-none tracking-tight text-slate-900">{value}</p>
      <p className="mt-1.5 text-xs font-semibold text-slate-700">{title}</p>
      <p className="mt-0.5 text-[11px] text-slate-500">{subtitle}</p>
      {note && <p className="mt-0.5 text-[11px] text-slate-500">{note}</p>}
    </article>
  );
};
