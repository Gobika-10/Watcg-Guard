interface HierarchyItem {
  name: string;
  percentage: string;
  widthPercent: number;
  tone: "red" | "green" | "gray";
}

interface OrganizationHierarchyCardProps {
  items: HierarchyItem[];
}

const toneClasses: Record<HierarchyItem["tone"], { bar: string; dot: string; label: string }> = {
  red: { bar: "bg-rose-500", dot: "bg-rose-500", label: "text-rose-600" },
  green: { bar: "bg-emerald-500", dot: "bg-emerald-500", label: "text-emerald-600" },
  gray: { bar: "bg-slate-500", dot: "bg-slate-500", label: "text-slate-600" },
};

export const OrganizationHierarchyCard = ({ items }: OrganizationHierarchyCardProps) => {
  return (
    <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="text-xs font-semibold uppercase tracking-widest text-slate-600">
          Organization Hierarchy
        </h3>
        <div className="flex items-center gap-3">
          {items.map((item) => (
            <span key={item.name} className="flex items-center gap-1.5 text-[10px] text-slate-500">
              <span className={`h-1.5 w-1.5 rounded-full ${toneClasses[item.tone].dot}`} />
              {item.name}
            </span>
          ))}
        </div>
      </div>

      <div className="space-y-3">
        {items.map((item) => {
          const t = toneClasses[item.tone];
          return (
            <div key={item.name} className="flex items-center gap-3">
              <p className="w-36 shrink-0 truncate text-xs text-slate-700">{item.name}</p>
              <div className="relative h-1.5 flex-1 rounded-full bg-slate-200">
                <div
                  className={`h-1.5 rounded-full ${t.bar} transition-all duration-700`}
                  style={{ width: `${Math.max(item.widthPercent, 1)}%` }}
                />
              </div>
              <span className={`w-10 shrink-0 text-right text-xs font-semibold tabular-nums ${t.label}`}>
                {item.percentage}
              </span>
            </div>
          );
        })}
      </div>
    </section>
  );
};
