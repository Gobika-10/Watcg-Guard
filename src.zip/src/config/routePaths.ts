export const routePaths = {
  dashboard: "/dashboard",
  newPurchase: "/new-purchase",
  renewals: "/renewals",
  invoicesBilling: "/invoices-billing",
  usageReports: "/usage-reports",
  supportTickets: "/support-tickets",
  accountSettings: "/account-settings",
} as const;
